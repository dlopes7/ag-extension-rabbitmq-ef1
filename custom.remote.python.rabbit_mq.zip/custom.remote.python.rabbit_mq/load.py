import pika
import time

from concurrent.futures import ThreadPoolExecutor


def producer(virtual_host, queue):
    creds = pika.credentials.PlainCredentials(username="guest", password="guest")
    parameters = pika.ConnectionParameters(host="localhost", port=5672, virtual_host=virtual_host, credentials=creds)
    connection = pika.BlockingConnection(parameters=parameters)
    try:
        while True:
            channel = connection.channel()
            message = f"Test message {time.time()}"
            print(f"Publish {virtual_host} {queue} {message}")
            channel.basic_publish(exchange="", routing_key=queue, body=message.encode())
            time.sleep(0.2)
    finally:
        connection.close()


def on_message(channel, method_frame, header_frame, body):
    print(f"Received: {channel} - {method_frame} - {header_frame} - {body}")
    channel.basic_ack(delivery_tag=method_frame.delivery_tag)


def consumer(virtual_host, queue):
    try:
        creds = pika.credentials.PlainCredentials(username="guest", password="guest")
        parameters = pika.ConnectionParameters(host="localhost", port=5672, virtual_host=virtual_host, credentials=creds)
        connection = pika.BlockingConnection(parameters=parameters)
        channel = connection.channel()
        channel.queue_declare(queue=queue, durable=True)
        channel.basic_consume(queue, on_message)
        try:
            channel.start_consuming()
        except KeyboardInterrupt:
            channel.stop_consuming()
        connection.close()
    except Exception as e:
        print(e)


def main():
    with ThreadPoolExecutor(max_workers=2) as e:
        e.submit(producer, "vh1", "q1")
        # e.submit(producer, "/", "q1")
        # e.submit(producer, "/", "q2")
        # e.submit(producer, "/", "q3")
        # e.submit(consumer, "vh2", "q2")
        e.submit(consumer, "vh1", "q1")


if __name__ == "__main__":
    main()
